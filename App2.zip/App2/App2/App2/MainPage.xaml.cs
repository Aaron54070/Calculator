﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Xamarin.Forms;

namespace App2
{
    public partial class MainPage : ContentPage
    {
        public MainPage()
        {
            InitializeComponent();
        }
        private decimal firstNumer;
        private string operatorName;
        private bool isOperatorClicked;
        private void Button1_Clicked(object sender, EventArgs e)
        {
            LblResult.Text = "1";
        }
        private void Buttoncom_Clicked(object sender, EventArgs e)
        {
            var button = sender as Button;
            if(LblResult.Text =="0" || isOperatorClicked)
            { 
                LblResult.Text = button.Text; 
            }
            else
            {
                LblResult.Text += button.Text;
            }
            
        }

        private void buttonclr_Clicked(object sender, EventArgs e)
        {
            LblResult.Text = "0";
        }

        private void buttonx_Clicked(object sender, EventArgs e)
        {
            string number = LblResult.Text;
            if(number!="0")
            {
                number = number.Remove(number.Length - 1,1);
                if(string.IsNullOrEmpty(number))
                {
                    LblResult.Text = "0";
                }
                else
                {
                    LblResult.Text = number;
                }
            }
        }
        private void buttoncommonoperator_Clicked(object sender,EventArgs e)
        {
            var button = sender as Button;
            isOperatorClicked = true;
            operatorName = button.Text;
            firstNumer = Convert.ToDecimal(LblResult.Text);
        }
        private async void buttonper_Clicked(object sender, EventArgs e)
        {
            try
            {
                string number = LblResult.Text;
                if (number!= "0")
                {
                    decimal percentValue = Convert.ToDecimal(number);
                    string result = (percentValue / 100).ToString("0.##");
                    LblResult.Text = result;
                }
            }
            catch(Exception ex)
            {
                await DisplayAlert("Error", ex.Message, "ok");
            }
        }

        private void buttonequals_Clicked(object sender, EventArgs e)
        {
            try
            {
                decimal secondNumber = Convert.ToDecimal(LblResult.Text);
                string finalResult = Calculate(firstNumer, secondNumber).ToString("0.##");
                LblResult.Text = finalResult;
            }
            catch (Exception ex)
            {
                DisplayAlert("Error", ex.Message, "ok");
            }
        }
        public decimal Calculate(decimal firstnumber, decimal secondnumber)
        {
            decimal result = 0;
            if(operatorName=="+")
            {
                result = firstnumber + secondnumber;
            }
            else if(operatorName=="-")
            {
                result = secondnumber - firstnumber;
            }
            else if(operatorName== "*")
            {
                result = firstnumber * secondnumber;

            }
            else if(operatorName == "/")
            {
                result = firstnumber / secondnumber;
            }
            return result;
        }
    }
}
